(function() {
  define(["angular"], function(angular) {
    "use strict";
    return angular.module("directives", []);
  });

}).call(this);

/*
//@ sourceMappingURL=directives.js.map
*/