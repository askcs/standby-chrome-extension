(function() {
  "use strict";
  chrome.runtime.onInstalled.addListener(function(details) {
    return console.log("previousVersion", details.previousVersion);
  });

}).call(this);

/*
//@ sourceMappingURL=background.js.map
*/