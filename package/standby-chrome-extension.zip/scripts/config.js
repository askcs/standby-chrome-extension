(function() {
  define({
    app: {
      version: "@@version",
      released: "@@released"
    }
  });

}).call(this);

/*
//@ sourceMappingURL=config.js.map
*/