(function() {
  'use strict';


}).call(this);

/*
//@ sourceMappingURL=popup.js.map
*/