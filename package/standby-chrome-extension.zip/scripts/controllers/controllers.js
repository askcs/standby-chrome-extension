(function() {
  define(["angular"], function(angular) {
    "use strict";
    return angular.module("controllers", []);
  });

}).call(this);

/*
//@ sourceMappingURL=controllers.js.map
*/