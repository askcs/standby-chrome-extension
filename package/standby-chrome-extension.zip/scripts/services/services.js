(function() {
  define(["angular"], function(angular) {
    "use strict";
    return angular.module("services", []);
  });

}).call(this);

/*
//@ sourceMappingURL=services.js.map
*/